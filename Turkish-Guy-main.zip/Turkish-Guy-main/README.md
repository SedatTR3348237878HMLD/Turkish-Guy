# tgttoollre
TürkishGuyTim İçin Yapılmış Bir Projedir.
Kodlar Çalınıp Değiştirilirse Haklarında Yasal İşlem Uygulanacaktır.
Tgt Üyeleri Kullanabilir.
Sorumluk Benim Götüme Batmaz
